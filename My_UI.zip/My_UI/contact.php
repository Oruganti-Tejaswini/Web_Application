<?php
//get data from form  

$name = $_POST['name'];
$email= $_POST['email'];
$message= $_POST['message'];
$to = "Tesuro.tsr@gmail.com";
$subject = "Contact form";
$txt ="Name = ". $name . "\r\n  Email = " . $email . "\r\n Message =" . $message;
$headers = "From: " . $email;

if($email!=NULL){
    mail($to,$subject,$txt,$headers);
}
//redirect
header("Location:home.html");
?>